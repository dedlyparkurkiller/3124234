﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Форма переопределяет dispose для очистки списка компонентов.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Является обязательной для конструктора форм Windows Forms
    Private components As System.ComponentModel.IContainer

    'Примечание: следующая процедура является обязательной для конструктора форм Windows Forms
    'Для ее изменения используйте конструктор форм Windows Form.  
    'Не изменяйте ее в редакторе исходного кода.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.ПочтаDataSet = New WindowsApp2213.ПочтаDataSet()
        Me.ПочтовыеОтделенияBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Почтовые_отделенияTableAdapter = New WindowsApp2213.ПочтаDataSetTableAdapters.Почтовые_отделенияTableAdapter()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ПочтовогоОтделенияDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.АдресDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ГазетыСТипографииDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.КолвоГазетDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ПочтаDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ПочтовыеОтделенияBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.ПочтовогоОтделенияDataGridViewTextBoxColumn, Me.АдресDataGridViewTextBoxColumn, Me.ГазетыСТипографииDataGridViewTextBoxColumn, Me.КолвоГазетDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.ПочтовыеОтделенияBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(-1, 0)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(542, 335)
        Me.DataGridView1.TabIndex = 0
        '
        'ПочтаDataSet
        '
        Me.ПочтаDataSet.DataSetName = "ПочтаDataSet"
        Me.ПочтаDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ПочтовыеОтделенияBindingSource
        '
        Me.ПочтовыеОтделенияBindingSource.DataMember = "Почтовые отделения"
        Me.ПочтовыеОтделенияBindingSource.DataSource = Me.ПочтаDataSet
        '
        'Почтовые_отделенияTableAdapter
        '
        Me.Почтовые_отделенияTableAdapter.ClearBeforeFill = True
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "№"
        Me.DataGridViewTextBoxColumn1.HeaderText = "№"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        '
        'ПочтовогоОтделенияDataGridViewTextBoxColumn
        '
        Me.ПочтовогоОтделенияDataGridViewTextBoxColumn.DataPropertyName = "№ почтового отделения"
        Me.ПочтовогоОтделенияDataGridViewTextBoxColumn.HeaderText = "№ почтового отделения"
        Me.ПочтовогоОтделенияDataGridViewTextBoxColumn.Name = "ПочтовогоОтделенияDataGridViewTextBoxColumn"
        '
        'АдресDataGridViewTextBoxColumn
        '
        Me.АдресDataGridViewTextBoxColumn.DataPropertyName = "Адрес"
        Me.АдресDataGridViewTextBoxColumn.HeaderText = "Адрес"
        Me.АдресDataGridViewTextBoxColumn.Name = "АдресDataGridViewTextBoxColumn"
        '
        'ГазетыСТипографииDataGridViewTextBoxColumn
        '
        Me.ГазетыСТипографииDataGridViewTextBoxColumn.DataPropertyName = "Газеты с типографии"
        Me.ГазетыСТипографииDataGridViewTextBoxColumn.HeaderText = "Газеты с типографии"
        Me.ГазетыСТипографииDataGridViewTextBoxColumn.Name = "ГазетыСТипографииDataGridViewTextBoxColumn"
        '
        'КолвоГазетDataGridViewTextBoxColumn
        '
        Me.КолвоГазетDataGridViewTextBoxColumn.DataPropertyName = "Кол-во газет"
        Me.КолвоГазетDataGridViewTextBoxColumn.HeaderText = "Кол-во газет"
        Me.КолвоГазетDataGridViewTextBoxColumn.Name = "КолвоГазетDataGridViewTextBoxColumn"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Button1.Location = New System.Drawing.Point(420, 362)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(121, 35)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Назад"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Teal
        Me.ClientSize = New System.Drawing.Size(551, 450)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "Form3"
        Me.Text = "Form3"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ПочтаDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ПочтовыеОтделенияBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents ПочтаDataSet As ПочтаDataSet
    Friend WithEvents ПочтовыеОтделенияBindingSource As BindingSource
    Friend WithEvents Почтовые_отделенияTableAdapter As ПочтаDataSetTableAdapters.Почтовые_отделенияTableAdapter
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents ПочтовогоОтделенияDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents АдресDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ГазетыСТипографииDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents КолвоГазетDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Button1 As Button
End Class
