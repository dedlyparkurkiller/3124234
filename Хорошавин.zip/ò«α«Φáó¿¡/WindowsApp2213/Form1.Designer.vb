﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Форма переопределяет dispose для очистки списка компонентов.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Является обязательной для конструктора форм Windows Forms
    Private components As System.ComponentModel.IContainer

    'Примечание: следующая процедура является обязательной для конструктора форм Windows Forms
    'Для ее изменения используйте конструктор форм Windows Form.  
    'Не изменяйте ее в редакторе исходного кода.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.ПочтаDataSet = New WindowsApp2213.ПочтаDataSet()
        Me.ГазетыBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ГазетыTableAdapter = New WindowsApp2213.ПочтаDataSetTableAdapters.ГазетыTableAdapter()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        CType(Me.ПочтаDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ГазетыBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ПочтаDataSet
        '
        Me.ПочтаDataSet.DataSetName = "ПочтаDataSet"
        Me.ПочтаDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ГазетыBindingSource
        '
        Me.ГазетыBindingSource.DataMember = "Газеты"
        Me.ГазетыBindingSource.DataSource = Me.ПочтаDataSet
        '
        'ГазетыTableAdapter
        '
        Me.ГазетыTableAdapter.ClearBeforeFill = True
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Button1.Location = New System.Drawing.Point(60, 84)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(124, 47)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Газеты"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Button4.Location = New System.Drawing.Point(470, 328)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(99, 31)
        Me.Button4.TabIndex = 3
        Me.Button4.Text = "Выход"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Button2.Location = New System.Drawing.Point(229, 84)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(124, 47)
        Me.Button2.TabIndex = 4
        Me.Button2.Text = "Почтовые отделения"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Button3.Location = New System.Drawing.Point(404, 84)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(124, 47)
        Me.Button3.TabIndex = 5
        Me.Button3.Text = "Типография"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Teal
        Me.ClientSize = New System.Drawing.Size(575, 375)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form1"
        CType(Me.ПочтаDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ГазетыBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ПочтаDataSet As ПочтаDataSet
    Friend WithEvents ГазетыBindingSource As BindingSource
    Friend WithEvents ГазетыTableAdapter As ПочтаDataSetTableAdapters.ГазетыTableAdapter
    Friend WithEvents Button1 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
End Class
