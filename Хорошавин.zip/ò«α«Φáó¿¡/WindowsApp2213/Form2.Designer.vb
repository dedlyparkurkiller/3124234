﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Форма переопределяет dispose для очистки списка компонентов.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Является обязательной для конструктора форм Windows Forms
    Private components As System.ComponentModel.IContainer

    'Примечание: следующая процедура является обязательной для конструктора форм Windows Forms
    'Для ее изменения используйте конструктор форм Windows Form.  
    'Не изменяйте ее в редакторе исходного кода.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.ПочтаDataSet = New WindowsApp2213.ПочтаDataSet()
        Me.ГазетыBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ГазетыTableAdapter = New WindowsApp2213.ПочтаDataSetTableAdapters.ГазетыTableAdapter()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.НазваниеГазетыDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ИндексИзданияDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ФИОИздателяDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ЦенаГазетыDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ТипографияDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ПочтаDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ГазетыBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.НазваниеГазетыDataGridViewTextBoxColumn, Me.ИндексИзданияDataGridViewTextBoxColumn, Me.ФИОИздателяDataGridViewTextBoxColumn, Me.ЦенаГазетыDataGridViewTextBoxColumn, Me.ТипографияDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.ГазетыBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(-1, 0)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(643, 263)
        Me.DataGridView1.TabIndex = 0
        '
        'ПочтаDataSet
        '
        Me.ПочтаDataSet.DataSetName = "ПочтаDataSet"
        Me.ПочтаDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ГазетыBindingSource
        '
        Me.ГазетыBindingSource.DataMember = "Газеты"
        Me.ГазетыBindingSource.DataSource = Me.ПочтаDataSet
        '
        'ГазетыTableAdapter
        '
        Me.ГазетыTableAdapter.ClearBeforeFill = True
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "№"
        Me.DataGridViewTextBoxColumn1.HeaderText = "№"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        '
        'НазваниеГазетыDataGridViewTextBoxColumn
        '
        Me.НазваниеГазетыDataGridViewTextBoxColumn.DataPropertyName = "Название газеты"
        Me.НазваниеГазетыDataGridViewTextBoxColumn.HeaderText = "Название газеты"
        Me.НазваниеГазетыDataGridViewTextBoxColumn.Name = "НазваниеГазетыDataGridViewTextBoxColumn"
        '
        'ИндексИзданияDataGridViewTextBoxColumn
        '
        Me.ИндексИзданияDataGridViewTextBoxColumn.DataPropertyName = "Индекс издания"
        Me.ИндексИзданияDataGridViewTextBoxColumn.HeaderText = "Индекс издания"
        Me.ИндексИзданияDataGridViewTextBoxColumn.Name = "ИндексИзданияDataGridViewTextBoxColumn"
        '
        'ФИОИздателяDataGridViewTextBoxColumn
        '
        Me.ФИОИздателяDataGridViewTextBoxColumn.DataPropertyName = "ФИО издателя"
        Me.ФИОИздателяDataGridViewTextBoxColumn.HeaderText = "ФИО издателя"
        Me.ФИОИздателяDataGridViewTextBoxColumn.Name = "ФИОИздателяDataGridViewTextBoxColumn"
        '
        'ЦенаГазетыDataGridViewTextBoxColumn
        '
        Me.ЦенаГазетыDataGridViewTextBoxColumn.DataPropertyName = "Цена газеты"
        Me.ЦенаГазетыDataGridViewTextBoxColumn.HeaderText = "Цена газеты"
        Me.ЦенаГазетыDataGridViewTextBoxColumn.Name = "ЦенаГазетыDataGridViewTextBoxColumn"
        '
        'ТипографияDataGridViewTextBoxColumn
        '
        Me.ТипографияDataGridViewTextBoxColumn.DataPropertyName = "Типография"
        Me.ТипографияDataGridViewTextBoxColumn.HeaderText = "Типография"
        Me.ТипографияDataGridViewTextBoxColumn.Name = "ТипографияDataGridViewTextBoxColumn"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Button1.Location = New System.Drawing.Point(515, 335)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(118, 44)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Назад"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Teal
        Me.ClientSize = New System.Drawing.Size(645, 394)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "Form2"
        Me.Text = "Form2"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ПочтаDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ГазетыBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents ПочтаDataSet As ПочтаDataSet
    Friend WithEvents ГазетыBindingSource As BindingSource
    Friend WithEvents ГазетыTableAdapter As ПочтаDataSetTableAdapters.ГазетыTableAdapter
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents НазваниеГазетыDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ИндексИзданияDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ФИОИздателяDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ЦенаГазетыDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ТипографияDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Button1 As Button
End Class
