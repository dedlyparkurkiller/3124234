﻿Public Class Form3
    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: данная строка кода позволяет загрузить данные в таблицу "ПочтаDataSet.Почтовые_отделения". При необходимости она может быть перемещена или удалена.
        Me.Почтовые_отделенияTableAdapter.Fill(Me.ПочтаDataSet.Почтовые_отделения)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Hide()
        Form1.Show()

    End Sub
End Class