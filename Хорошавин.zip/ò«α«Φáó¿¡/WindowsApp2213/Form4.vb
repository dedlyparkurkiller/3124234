﻿Public Class Form4
    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: данная строка кода позволяет загрузить данные в таблицу "ПочтаDataSet.Типография". При необходимости она может быть перемещена или удалена.
        Me.ТипографияTableAdapter.Fill(Me.ПочтаDataSet.Типография)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Hide()
        Form1.Show()

    End Sub
End Class