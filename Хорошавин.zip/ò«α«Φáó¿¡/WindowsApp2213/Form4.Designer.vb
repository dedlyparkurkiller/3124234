﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Форма переопределяет dispose для очистки списка компонентов.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Является обязательной для конструктора форм Windows Forms
    Private components As System.ComponentModel.IContainer

    'Примечание: следующая процедура является обязательной для конструктора форм Windows Forms
    'Для ее изменения используйте конструктор форм Windows Form.  
    'Не изменяйте ее в редакторе исходного кода.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.ПочтаDataSet = New WindowsApp2213.ПочтаDataSet()
        Me.ТипографияBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ТипографияTableAdapter = New WindowsApp2213.ПочтаDataSetTableAdapters.ТипографияTableAdapter()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.УлицаОтделенияDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.НазваниеОтделенияDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ГазетаDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ПочтаDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ТипографияBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.УлицаОтделенияDataGridViewTextBoxColumn, Me.НазваниеОтделенияDataGridViewTextBoxColumn, Me.ГазетаDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.ТипографияBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(0, -1)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(443, 323)
        Me.DataGridView1.TabIndex = 0
        '
        'ПочтаDataSet
        '
        Me.ПочтаDataSet.DataSetName = "ПочтаDataSet"
        Me.ПочтаDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ТипографияBindingSource
        '
        Me.ТипографияBindingSource.DataMember = "Типография"
        Me.ТипографияBindingSource.DataSource = Me.ПочтаDataSet
        '
        'ТипографияTableAdapter
        '
        Me.ТипографияTableAdapter.ClearBeforeFill = True
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "№"
        Me.DataGridViewTextBoxColumn1.HeaderText = "№"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        '
        'УлицаОтделенияDataGridViewTextBoxColumn
        '
        Me.УлицаОтделенияDataGridViewTextBoxColumn.DataPropertyName = "Улица отделения"
        Me.УлицаОтделенияDataGridViewTextBoxColumn.HeaderText = "Улица отделения"
        Me.УлицаОтделенияDataGridViewTextBoxColumn.Name = "УлицаОтделенияDataGridViewTextBoxColumn"
        '
        'НазваниеОтделенияDataGridViewTextBoxColumn
        '
        Me.НазваниеОтделенияDataGridViewTextBoxColumn.DataPropertyName = "Название отделения"
        Me.НазваниеОтделенияDataGridViewTextBoxColumn.HeaderText = "Название отделения"
        Me.НазваниеОтделенияDataGridViewTextBoxColumn.Name = "НазваниеОтделенияDataGridViewTextBoxColumn"
        '
        'ГазетаDataGridViewTextBoxColumn
        '
        Me.ГазетаDataGridViewTextBoxColumn.DataPropertyName = "Газета"
        Me.ГазетаDataGridViewTextBoxColumn.HeaderText = "Газета"
        Me.ГазетаDataGridViewTextBoxColumn.Name = "ГазетаDataGridViewTextBoxColumn"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Button1.Location = New System.Drawing.Point(351, 348)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(92, 43)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Назад"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Form4
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Teal
        Me.ClientSize = New System.Drawing.Size(444, 450)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "Form4"
        Me.Text = "Form4"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ПочтаDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ТипографияBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents ПочтаDataSet As ПочтаDataSet
    Friend WithEvents ТипографияBindingSource As BindingSource
    Friend WithEvents ТипографияTableAdapter As ПочтаDataSetTableAdapters.ТипографияTableAdapter
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents УлицаОтделенияDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents НазваниеОтделенияDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ГазетаDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Button1 As Button
End Class
